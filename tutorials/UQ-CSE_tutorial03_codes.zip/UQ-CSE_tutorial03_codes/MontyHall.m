clc; clear; close all;
N = 100; d = 3; win=0; lose=0; Monty=0;
for i = 1:N
  % define the doors content
  Car = randi(d)-1; Choose = randi(d)-1;
  while (Monty == Car || Monty == Choose), Monty = randi(d)-1; end
  % check the result
  if Choose == Car, lose = lose + 1; else win = win + 1; end
  % display round results
  disp(['Round ',num2str(i)]); disp('Chosen door:');
  disp([zeros(1,Choose),1,zeros(1,(d-1)-Choose)]);
  if Car < Choose, disp('Monty opens:');
    disp([ones(1,Car),0,ones(1,Choose-Car-1),0,ones(1,(d-1)-Choose)]); 
  end
  if Car > Choose, disp('Monty opens:');
    disp([ones(1,Choose),0,ones(1,Car-Choose-1),0,ones(1,(d-1)-Car)]); 
  end
  if Car == Choose
    if Car < Monty, disp('Monty opens:');
        disp([ones(1,Car),0,ones(1,Monty-Car-1),0,ones(1,(d-1)-Monty)]); 
    else disp('Monty opens:');
        disp([ones(1,Monty),0,ones(1,Car-Monty-1),0,ones(1,(d-1)-Car)]);
    end
  end
  disp('Car is behind:'); disp([zeros(1,Car),1,zeros(1,(d-1)-Car)]);
  if Choose==Car, disp('Switching loses'); else disp('Switching wins');end
  disp(' '); disp('   Win | Lose'); disp([win,lose]);
  disp('---------------------');
end
disp(['Won  ',num2str(win)]); disp(['Lost ',num2str(lose)]); 
disp(['Estimated chance of winning after switch: ',num2str(win/N)]);