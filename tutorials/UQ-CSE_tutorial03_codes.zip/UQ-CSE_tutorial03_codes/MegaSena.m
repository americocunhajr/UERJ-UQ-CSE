clc; clear; close all

% number of possible games
N = 50063860;

% number of bets time-series
n = 1:1:N;

% Player 1 probability
prob1 = n/N;

% Player 2 probability
prob2 = 1 - (1 - 1/N).^n;

% plot graphs
plot(n,prob1,'b',n,prob2,'r','LineWidth',2);
set(gca,'fontsize',18)
legend('Player 1','Player 2')
xlabel('number of bets')
ylabel('probability')