clc; clear; close all;

a = 2; b = 5; Ns = 1000;

X     = betarnd(a,b,Ns,1);
Nbins = round(sqrt(Ns));
Nksd  = round(0.1*Ns);

[X_bins,X_freq,X_area] = randvar_pdf(X,Nbins);
[X_ksd ,X_supp1      ] = ksdensity(X);
[X_cdf ,X_supp2      ] = ecdf(X);

figure(1)
bar(X_bins,X_freq,1.0);
hold on
plot(X_supp1,X_ksd,'r','linewidth',3)
xlim([0 1]);
hold off

figure(2)
plot(X_supp2,X_cdf,'r','linewidth',3)
xlim([0 1]); ylim([0 1]);