clc; clear; close all;

a = 5.0; b = 1.0; Ns = 1000; Pc = 95;

X = gamrnd(a,b,Ns,1);
mu = mean(X); sigma = std(X); mu50 = median(X);
r_plus = 0.5*(100 + Pc); r_minus = 0.5*(100 - Pc);
X_upp = prctile(X,r_plus); X_low = prctile(X,r_minus);

figure(1)
plot(X,'xc');
hold on
line([1 Ns],[mu mu            ],'Color','k','LineStyle','- ','linewidth',2);
line([1 Ns],[mu50 mu50        ],'Color','r','LineStyle','--','linewidth',2);
line([1 Ns],[mu-sigma mu-sigma],'Color','b','LineStyle','-.','linewidth',2);
line([1 Ns],[X_low X_low      ],'Color','m','LineStyle',': ','linewidth',2);
line([1 Ns],[mu+sigma mu+sigma],'Color','b','LineStyle','-.','linewidth',2);
line([1 Ns],[X_upp X_upp      ],'Color','m','LineStyle',': ','linewidth',2);
legend('samples','mean','median','mean \pm std','95% interval')
hold off

