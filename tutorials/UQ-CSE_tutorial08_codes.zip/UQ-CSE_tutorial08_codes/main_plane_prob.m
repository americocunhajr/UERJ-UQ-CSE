clear; close all; clc

% sample size
Ns = 100000;

% draw the samples
X = -0.5 + rand(Ns,3);

% sum of the coordinates
SumCoord = sum(X,2);

% count the number of hits
count = sum(SumCoord == 1)

% compute the estimated volume
P_plane = count/Ns
P_true  = 0