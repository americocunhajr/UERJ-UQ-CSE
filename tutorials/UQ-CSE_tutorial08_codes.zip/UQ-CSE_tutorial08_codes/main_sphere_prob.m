clear; close all; clc

% sample size
Ns = 100000;

% draw the samples
X = -0.5 + rand(Ns,3);

% distance from the origin for each sample
R = sqrt(sum(X.^2,2));

% count the number of hits
count = sum(R <= 1/2)

% compute the estimated volume
P_sphere = count/Ns
P_true   = pi/6
rel_error = (abs(P_sphere-P_true)/abs(P_true))*100