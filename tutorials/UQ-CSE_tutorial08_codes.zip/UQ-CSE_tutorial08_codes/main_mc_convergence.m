clc
clear all
close all


% define stochastic parameters
rng_stream = RandStream('mt19937ar','Seed',30081984);
RandStream.setDefaultStream(rng_stream); % matlab 2009
%RandStream.setGlobalStream(rng_stream); % matlab 2013

% number of samples
Ns = 10^7;

% normal
X1 = randn(Ns,1);

% cauchy
m = 0.0; b = 1.0;
X2 = m + b*tan(pi*(rand(Ns,1)-1/2));


conv1 = cumsum(X1.^2)./(1:Ns)';
conv2 = cumsum(X2.^2)./(1:Ns)';

figure(1)
loglog(1:Ns,conv1,'x')
title(' Convergence of Monte Carlo','FontSize',20)
set(gca,'fontsize',18)
xlabel('sample')
ylabel('2nd moment')
xlim([1,1e7])
%set(gca,'XGrid','on','YGrid','on');

figure(2)
loglog(1:Ns,conv2,'x')
title(' Convergence of Monte Carlo','FontSize',20)
set(gca,'fontsize',18)
xlabel('sample')
ylabel('2nd moment')
xlim([1,1e7])
%set(gca,'XGrid','on','YGrid','on');