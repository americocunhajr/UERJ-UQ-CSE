clc
clear all
close all

t0  = 0.0;   % initial time of analysis (s)
t1  = 30.0;  % final time of analysis (s)
Ndt = 300;   % number of time steps

m  = 1.0;    % system mass (kg)
c  = 0.1;    % damper constant (N.s/m)
k  = 5.0;    % stiffness constant (N/m)
x0 = 1.0;    % initial position (m)
v0 = 1.0;    % initial velocity (m/s)

% define stochastic parameters
rng_stream = RandStream('mt19937ar','Seed',30081984);
RandStream.setGlobalStream(rng_stream);

% number of samples
Ns = 1024;
% preallocate memory for displacement and velocity
Qd = zeros(Ndt,Ns);
Qv = zeros(Ndt,Ns);
% stiffness mean (N/m)
mean_k = k;
% stiffness coef. var
coefvar_k = 0.3;
% generate stiffness with Gamma distribution (N/m)
k = gamrnd(1/coefvar_k^2,mean_k*coefvar_k^2,[Ns,1]);
%k = mean_k*(1+coefvar_k*randn(Ns,1));

% init. cond. and interval of analysis
IC = [x0 v0]; tspam = linspace(t0,t1,Ndt);

% Monte Carlo method
for n=1:Ns

    % system of equations
    dydt=@(t,y)[0 1; -k(n) -c]*y;
    
    % ODE solver Runge-Kutta45
    [t,y] = ode45(dydt,tspam,IC);
    
    % time series of system displacement (m)
    Qd(:,n) = y(:,1);
    
    % time series of system velocity (m/s)
    Qv(:,n) = y(:,2);
end

% sample mean
Qd_smean = mean(Qd');
Qv_smean = mean(Qv');

% temporal mean
Qd_tmean = mean(Qd);
Qv_tmean = mean(Qv);

% std. dev.
Qd_std  = std(Qd');
Qv_std  = std(Qv');

% confidence band
Pc = 95; 
r_plus = 0.5*(100 + Pc); r_minus = 0.5*(100 - Pc);
Qd_upp = prctile(Qd',r_plus);
Qv_upp = prctile(Qv',r_plus);
Qd_low = prctile(Qd',r_minus);
Qv_low = prctile(Qv',r_minus);

% histogram of temporal mean
Nbins = round(sqrt(Ns));
[Qd_bins,Qd_freq] = randvar_pdf(Qd_tmean,Nbins);
[Qv_bins,Qv_freq] = randvar_pdf(Qv_tmean,Nbins);

% kernel density estimator for temporal mean
[Qd_ksd,Qd_supp] = ksdensity(Qd_tmean);
[Qv_ksd,Qv_supp] = ksdensity(Qv_tmean);

figure(1)
fh1 = plot(t,Qd_smean,'b','linewidth',3); hold on
fh2 = plot(t,Qd_std,'r','linewidth',3);
fh3 = fill([t' fliplr(t')],[Qd_upp fliplr(Qd_low)],'y');
uistack(fh3,'top');
uistack(fh2,'top');
uistack(fh1,'top');
legend('envelope','std','mean')
hold off

figure(2)
fh1 = plot(t,Qv_smean,'b','linewidth',3); hold on
fh2 = plot(t,Qv_std,'r','linewidth',3);
fh3 = fill([t' fliplr(t')],[Qv_upp fliplr(Qv_low)],'y');
uistack(fh3,'top');
uistack(fh2,'top');
uistack(fh1,'top');
legend('envelope','std','mean')
hold off

figure(3)
bar(Qd_bins,Qd_freq,1.0);
hold on
plot(Qd_supp,Qd_ksd,'r','linewidth',3)
hold off

figure(4)
bar(Qv_bins,Qv_freq,1.0);
hold on
plot(Qv_supp,Qv_ksd,'r','linewidth',3)
hold off


conv = sqrt(cumsum(mean(Qd.^2))./(1:Ns));
figure(5)
loglog(1:Ns,conv(1:Ns),'xb')
