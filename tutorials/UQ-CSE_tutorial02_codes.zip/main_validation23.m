m = 1.0; ksi = 0.095; wn = 4.08; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi + [0; (f/m)*sin(w*t)];
[t_cal,phi_cal] = euler(dphidt,[x0;v0],t0,t1,N);

figure(4)
plot(t_cal,phi_cal(1,:),'g',t_uncal,phi_uncal(1,:),'b','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'xr','LineWidth',3);
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
hold off
axis([t0 t1 -2 2]); set(gca,'fontsize',18);
legend('Calibrated','Uncalibrated','Experiment 1')
      
figure(5)
plot(t_cal,phi_cal(1,:),'g','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'xr','LineWidth',3);
plot(t_exp2,x_exp2,'ok','LineWidth',3);
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
plot(t_exp2,x_exp2,'--k','LineWidth',0.3);
hold off
axis([t0 t1 -2 2]); set(gca,'fontsize',18);
legend('Calibrated','Experiment 1','Experiment 2')