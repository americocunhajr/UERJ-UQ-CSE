clc; clear; close all;
m = 1.0; ksi = 0.1; wn = 4.0; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0; t0 = 0.0; t1 = 30.0; N = 5000;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [0; (f/m)*sin(w*t)];

[t,phi] = euler(dphidt,[x0;v0],t0,t1,N);

t_exp = t(1:50:end);
x_exp = phi(1,1:50:end) + 0.01*randn;

plot(t,phi(1,:),'b',t_exp,x_exp,'xr','LineWidth',3);
axis([t0 t1 -2 2])
legend('Model','Experiment')