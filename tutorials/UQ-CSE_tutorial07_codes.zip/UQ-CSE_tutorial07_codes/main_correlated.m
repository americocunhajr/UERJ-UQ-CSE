clc; clear; close all;

Ns = 1024; mu = [2 3]; Sigma = [1.0 1.5; 1.5 3.0];
R = mvnrnd(mu,Sigma,Ns); Z1 = R(:,1); Z2 = R(:,2);

figure(1)
plot(Z1,Z2,'*b','LineWidth',3);
xlim([-2 6]); ylim([-1 7]);

figure(2)
hist3([R(:,1),R(:,2)],'FaceColor','m');
xlim([-2 6]); ylim([-1 7]);