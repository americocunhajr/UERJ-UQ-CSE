clc; clear; close all;

a = 7.5; b = 1.0; Nx = 500; Ns = 256; U = rand(Ns,1);

Xsupp = linspace(0.0,20.0,Nx);
Xcdf  = gamcdf(Xsupp,a,b);
Xsamp = interp1(Xcdf,Xsupp,U,'linear','extrap');
Xpdf  = gampdf(Xsupp,a,b); 

[Xbins,Xfreq] = randvar_pdf(Xsamp,round(sqrt(Ns)));

figure(1)
bar(Xbins,Xfreq,1.0);
hold on
plot(Xsupp,Xpdf,'r','LineWidth',3)
hold off