clc; clear; close all;

Ns = 256; U1 = rand(Ns,1); U2 = rand(Ns,1);
R = sqrt(-2*log(U1)); THETA = 2*pi*U2;
Z1 = R.*cos(THETA); Z2 = R.*sin(THETA);

[Xbins1,Xfreq1] = randvar_pdf(Z1,round(sqrt(Ns)));
[Xbins2,Xfreq2] = randvar_pdf(Z2,round(sqrt(Ns)));

figure(1)
plot(Z1,Z2,'*b','LineWidth',3);
xlim([-4 4]); ylim([-4 4]);

figure(2)
bar(Xbins1,Xfreq1,1.0,'FaceColor','r');
hold on
bar(Xbins2,Xfreq2,1.0,'FaceColor','c','FaceAlpha',0.5);
plot(-4:0.05:4,normpdf(-4:0.05:4),'b','LineWidth',3);
hold off
xlim([-4 4]);

figure(3)
hist3([Z1,Z2],'FaceColor','m');
xlim([-4 4]); ylim([-4 4]);