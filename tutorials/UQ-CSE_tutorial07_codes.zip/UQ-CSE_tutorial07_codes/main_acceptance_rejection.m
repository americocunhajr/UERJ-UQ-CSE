clc; clear; close all;
Ns = 1024; Z = NaN(Ns,1);
for it=1:Ns
    while 1
        Y1 = -log(rand); Y2 = -log(rand);
        if Y2 >= (Y1-1).^2/2
            absZ = Y1;
            break
        end
    end
    U = rand;
    if U > 0.5
        Z(it) = -absZ;
    else
        Z(it) = absZ;
    end
end
[Xbins,Xfreq] = randvar_pdf(Z,round(sqrt(Ns)));
figure(1)
bar(Xbins,Xfreq,1.0);
hold on
plot(-4:0.05:4,normpdf(-4:0.05:4),'r','LineWidth',3);
hold off
xlim([-4 4]);