clc; clear; close all

% number of tosses / head probability
Ntoss = 1000; p = 0.5;
% sequence of heads size
s = 10; Hseq = ones(1,s);
% experiment realizations (head = 1 / tail = 0)
HTexp = rand(1,Ntoss) < p;
disp('------------------------')
disp(' Flip a Coin Experiment')
disp('------------------------')
for i=1:Ntoss
    if HTexp(i) == 1
        disp('  H')
    else
        disp('  T')
    end
end
H = sum(HTexp); T = Ntoss-H; N_Hseq = length(strfind(HTexp,Hseq));
disp(['Heads: ',num2str(H)]) 
disp(['Tails: ',num2str(T)]) 
disp(['Sequences with ',num2str(s),' heads : ',num2str(N_Hseq)])