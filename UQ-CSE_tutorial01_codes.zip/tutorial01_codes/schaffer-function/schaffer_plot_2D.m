% ----------------------------------------------------------------- 
%  programmer: Marcos Vinicius Issa
%              marcos.issa@uerj.br
%
%  last update: August 08, 2021
% -----------------------------------------------------------------

function schaffer_plot_2D(x1min,x1max,x2min,x2max)

% Contour Plot

hold on
    
    [x1, x2] = meshgrid (x1min:0.01:x1max,x2min:0.01:x2max);
    
    %Schaffer Function
    J = 0.5 + (sin(x1.^2 - x2.^2).^2 - 0.5)./((1 + 0.001.*(x1.^2 + x2.^2)).^2);
    
    mesh(x1,x2,J);
    
    xlabel('\it{x_1}','FontSize',20); ylabel('\it{x_2}','FontSize',20);
    zlabel('$f(x)$','Interpreter','latex','FontSize',20);
    
    
    set(gca,'FontSize',20)
    
    az = 50;
    el = 25;
    view(az, el);

hold off


end