% -----------------------------------------------------------------
%  main_sir.m
% -----------------------------------------------------------------
%
% This is a main file for the SIR epidemic model, which
% divides a population in 3 compartments:
%
%   S = susceptible
%   I = infected
%   R = recovered
%
% Infection spreads via direct contact between
% a susceptible and infected individual, with no delay.
% No deaths are considered, all infected become recovered.
%
% This model has 3 parameters:
%
%   N     = population size   (number of individuals)
%   beta  = transmission rate (days^-1)
%   gamma = recovery rate     (days^-1)
%
% This code uses model_sir.m to define and solve the ODE system
% and output the plot containing R_nought value. 
% Calculations are made on a day time scale.
%
% Input:
%   param: model parameters and initial conditions
%   tspan: time interval         
%
% Output:
%   figure(1): model state in time         - inplace figure
%   sir_results.png: saves the figure(1)
% -----------------------------------------------------------
% programmers: Rachel Lucena
%              Eber Dantas
%              Americo Cunha
%
% last update: August 09, 2021
% -----------------------------------------------------------

clc
clear
close all

% -----------------------------------------------------------  
% Model parameters

% population size (number of individuals)
param.N = 1000;
        
% transmission rate (days^-1)
param.beta = 1/4;

% recovery period (days)
Tgamma = 20;

% recovery rate (days^-1)
param.gamma  = 1/Tgamma;

% -----------------------------------------------------------
%% Initial conditions
R0 = 0;        % initial recovered   (number of individuals)
I0 = 1;        % initial infected    (number of individuals)
S0 = param.N-I0-R0;  % initial susceptible (number of individuals)

% initial conditions vector
param.IC = [S0 I0 R0];

% -----------------------------------------------------------
%% Integration of the initial value problem
% time interval of analysis
   t0 = 1;                  % initial time (days)
   t1 = 150;                % final time   (days)
   dt = 0.1;                % time steps   (days)
tspan = t0:dt:t1;           % interval of analysis

%% Solving the system of equations
QoI = model_sir(param,tspan);


%% Recovering the results
% time series solved
S = QoI(:,1);     % susceptible         (number of individuals)
I = QoI(:,2);     % infected            (number of individuals)
R = QoI(:,3);     % recovered           (number of individuals)
time = QoI(:,4);  % time                (days)
% -----------------------------------------------------------

%% Computing the basic reproduction number R_nought
Rnought = param.beta/param.gamma;
% -----------------------------------------------------------

%% Plotting all compartments of SIR model
figure(1)
hold on
fig1(1) = plot(time,S);
fig1(2) = plot(time,I);
fig1(3) = plot(time,R);
hold off

% plot labels
filename_fig1 = (['SIR dynamic model - Ro = ',num2str(Rnought)]);
title(filename_fig1);
xlabel('time (days)'          );
ylabel('number of individuals');

% set plot settings
set(gca,'FontSize',18);
set(fig1,{'Color'},{'b';'r';'g'});
set(fig1,{'LineWidth'},{2;2;2});

% legend
leg = {'Suceptibles'; 'Infected'; 'Recovered'};
legend(fig1,leg,'FontSize',12,'location','best');

% axis limits
xlim([t0 t1]);
ylim([0 param.N]);

% saving
set(gcf,'renderermode','manual', 'render','zbuffer');
saveas(gcf,'sir_results.png')

% -----------------------------------------------------------
