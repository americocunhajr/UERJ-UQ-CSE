% -----------------------------------------------------------------
%  harmonic_ODE45.m
% -----------------------------------------------------------------
%  programmer: Diego Matos Silva Lopes
%              diego.matos@uerj.br
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
%    
%  ================================================================
%  Input:
%  alpha - parameter of the rossler system y' = x + alpha*y
%  beta - parameter of the rossler system z' = beta + z(x-gamma)
%  gamma - parameter of the rossler system z' = beta + z(x-gamma)
%  IC - initial condition
%  tspan - interval time that the integration occur
%
%  ================================================================
%  Output:
%  t - time vector with each time step of the integration.
%  dynamics - matrix with the result of the numerical integration of...
%  the Rossler system, contains the coordenates of x, y, and z along the time t.
% -----------------------------------------------------------------

function [t,dynamics] = harmonic_ODE45(m,c,k,f,w,IC,tspan)

param = [c/m,k/m,f/m,w];
N = length(tspan);
[t,dynamics]=ode45(@(t,x)harmonic_equation(t,x,param),tspan,IC);

end

function dy = harmonic_equation(t,y,param)

dy = [
y(2);
-param(1)*y(2) - param(2)*y(1) + param(3)*cos(param(4)*t);
];

end