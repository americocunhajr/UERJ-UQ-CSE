% -----------------------------------------------------------------
%  model_ShearBuilding.m
% -----------------------------------------------------------------
%  programmer: João Pedro Norenberg
%              jp.norenberg@unesp.br
%
%  last update: August 6, 2021
% -----------------------------------------------------------------
%  This function computes the quantity of interest (QoI) for
%  a Shear Building structure.
% -----------------------------------------------------------------
%
%  ================================================================
%  Input:
%  X    - model parameters
%  X.En - Young's Modulus (Pa) 
%  X.bn - width column (m)
%  X.hn - thickness column (m)
%  X.Ln - length column (m)
%  X.mn - mass (kg)
%
%  n = {1,2,3} - for each floor
%  ================================================================
%  Output:
%  QoI - quantity of interest
%  Natural frequency (Hz)
%
% -----------------------------------------------------------------

% -----------------------------------------------------------------
function QoI = model_ShearBuilding(X)
    

    % Physical parameters
    % Young's Modulus (Pa)
    E1 = X.E1;
    E2 = X.E2;
    E3 = X.E3;
    
    % width column (m)
    b1 = X.b1;
    b2 = X.b2;
    b3 = X.b3;
    
    % thickness column (m)
    h1 = X.h1;
    h2 = X.h2;
    h3 = X.h3;
    
    % length column (m)
    L1 = X.L1;
    L2 = X.L2;
    L3 = X.L3;
    
    % mass of floor (kg)
    m1 = X.m1;
    m2 = X.m2;
    m3 = X.m3;
    
    % inertial moment
    I1 = b1*h1^3/12;
    I2 = b2*h2^3/12;
    I3 = b3*h3^3/12;
    
    % stiffness    
    k1 = 3*E1*I1/L1^3;
    k2 = 3*E2*I2/L2^3;
    k3 = 3*E3*I3/L3^3;
    
    % matrix stiffness
    K = [k1+k2 -k2    0  ;
         -k1   k2+k3  -k3;   
         0     -k3    k3 ];
    
    % matrix mass
    M = diag([m1,m2,m3]);
    
    % Eig-value calculation
    [L,V] = eig(K,M);
    
    % Natural frequency (Hz)
    QoI = diag(V)/(2*pi);
end
% -----------------------------------------------------------------
