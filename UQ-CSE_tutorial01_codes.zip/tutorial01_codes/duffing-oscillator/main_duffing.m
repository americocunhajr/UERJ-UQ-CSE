% -----------------------------------------------------------------
%  main_duffing.m
% -----------------------------------------------------------------
%  programmer: João Pedro Norenberg
%              jp.norenberg@unesp.br
%
%  last update: August 6, 2021
% -----------------------------------------------------------------
%  This main file run the quantity of interest (QoI) for
%  a given duffing system.
% -----------------------------------------------------------------

clear all
close all
clc

% ----------------------------------------------------------------

disp('---  defining model parameters ---');

% Physical parameters
X.alpha = -1;       % linear stiffness
X.beta  = 1;        % nonlinear stiffness
X.delta = 0.3;      % rate of damping
X.gamma = 0.33;     % amplitude force
X.Omega = 1.2;      % frequency excitation

% Initial conditions
P.IC = [1,0];       % [inital displacement, initial velocity]

% Time of integration
ti = 0;             % initial time
tf = 150;           % final time
dt = 0.01;          % increment time
P.tspan = ti:dt:tf; % vector time

% ----------------------------------------------------------------

disp('                ...               ');
disp('---         integration        ---');

% Quantity of interest: time-displacement
QoI = model_duffing(X,P);

% ----------------------------------------------------------------

disp('                ...               ');
disp('---           plotting         ---');

% plotting time-response
plot(P.tspan,QoI,'linewidth',2)

set(gca,'FontName','Arial','FontSize',15,'linewidth',1.2);
set(gcf,'color','w');
xlabel(    'time'    ,'FontSize',15,'FontWeight','bold')
ylabel('displacement','FontSize',15,'FontWeight','bold')

saveas(gcf,'displ_duffing','png')

% ----------------------------------------------------------------

disp('                ...               ');
disp('---    successfully finished   ---');