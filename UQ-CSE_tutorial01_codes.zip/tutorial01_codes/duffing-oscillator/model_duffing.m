% -----------------------------------------------------------------
%  model_duffing.m
% -----------------------------------------------------------------
%  programmer: João Pedro Norenberg
%              jp.norenberg@unesp.br
%
%  last update: August 6, 2021
% -----------------------------------------------------------------
%  This function computes the quantity of interest (QoI) for
%  a given duffing system.
% -----------------------------------------------------------------
%
%  ================================================================
%  Input:
%  X        - model parameters
%  X.alpha  - linear stiffness
%  X.beta   - nonlinear stiffness
%  X.delta  - damping rate
%  X.gamma  - amplitude force
%  X.Omega  - frequency excitation
%  
%  P - model hyperparameters
%  P.tspan - time of integration
%  P.Ic    - initial conditions
%
%  ================================================================
%  Output:
%  QoI - quantity of interest
%  QoI - vector of displacement
% -----------------------------------------------------------------

% -----------------------------------------------------------------
function QoI = model_duffing(X,P)
    
    % Physical parameters
    alpha = X.alpha;
    gamma = X.gamma;
    delta = X.delta;
    beta  = X.beta;
    Omega = X.Omega;

    
    % Initial conditions
    IC    = P.IC;

    % Time of integration
    tspan = P.tspan;

    % Equation of motion
    dXdT = @(t,x)[x(2); 
                  -delta*x(2) - alpha*x(1) - beta*x(1)^3 + gamma*cos(t*Omega)];
	
	% ODE solver optional parameters
    opt = odeset('RelTol',1.0e-9,'AbsTol',1.0e-9);
    
	% Integration of equation of motion
    [time,x] = ode45(dXdT,tspan,IC,opt);
    
    % Quantity of interest: displacement
    QoI   = x(:,1);
end
% -----------------------------------------------------------------
