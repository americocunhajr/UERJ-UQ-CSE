% -----------------------------------------------------------------
%  main_seiahrd.m
% -----------------------------------------------------------------
%
% This is the main file for the SEIAHRD epidemic model, which
% divides a population in 7 compartments:
%
%   S = susceptibles
%   E = exposed
%   I = symptomatic infectious
%   A = asymptomatic infectious
%   H = hospitalized
%   R = recovered
%   D = deceased
%
% Infection spreads via direct contact between
% a susceptible and infectious individual.
% Delay is modeled as an exposed group: there is an
% latent period until an infected becomes able to transmit.
% Among the infectious, most individuals are asymptomatic; only
% a small fraction display symptoms after incubation.
% Disease-related deaths are considered when infectious.
% A control procedure is considered: a fraction of the infectious,
% is hospitalized, thus reducing their infectivity and fatality chance.
%
% This model has 9 parameters:
%
%   N0       = initial population size            (number of individuals)
%   beta     = transmission rate                  (days^-1)
%   alpha    = latent rate                        (days^-1)
%   fE       = symptomatic fraction               (dimensionless)
%   gamma    = recovery rate                      (days^-1)
%   rho      = hospitalization rate               (days^-1)
%   delta    = death rate                         (days^-1)
%   kappaH   = hospitalization mortality-factor   (dimensionless)
%
% This codes uses model_seiahrd.m to define and solve the ODE system
% and output the plot containing R_nought and R_control values. 
% Calculations are made on a day time scale.
%
% Input:
%   param: model parameters and initial conditions
%   tspan: time interval   
%
% Outputs:
%   figure(1): model state in time         - inplace figure
%   seiahrd_results.png: saves the figure(1)
% -----------------------------------------------------------
% programmers: Rachel Lucena
%              Eber Dantas
%              Americo Cunha
%
% last update: August 09, 2021
% -----------------------------------------------------------

clc
clear
close all

% -----------------------------------------------------------  
% Model parameters

% initial population size (number of individuals)
param.N0 = 1000;
        
% transmission rate (days^-1)
param.beta = 1/4;

% hospitalization infectivity-factor (dimensionless)
%
% -- Models contact diminishment. 

% latent period (days)
param.Talpha = 7;

% latent rate (days^-1)
param.alpha = 1/param.Talpha;

% symptomatic fraction (dimensionless)
%
% -- Models fraction of infectious that display symptoms. 
% -- Values: 0<fE<1.
param.fE = 0.5;

% recovery period (days)
param.Tgamma = 10;

% recovery rate (days^-1)
param.gamma = 1/param.Tgamma;

% hospitalization rate (days^-1)
param.rho = 1/7;

% death rate (days^-1)
param.delta = 1/15;

% Hospitalization mortality-factor (dimensionless)
%
% -- Models mortality diminishment.  
% -- Values: 0<kappaH<1.
param.kappaH = 0.5;

% -----------------------------------------------------------
%% Initial conditions
D0 = 0;                 % initial deceased                (number of individuals)
R0 = 0;                 % initial recovered               (number of individuals)
H0 = 0;                 % initial hospitalized            (number of individuals)
A0 = 0;                 % initial asymptomatic infectious (number of individuals)
I0 = 1;                 % initial symptomatic infectious  (number of individuals)
E0 = 0;                 % initial exposed                 (number of individuals)
S0 = param.N0-E0-I0-A0-H0-R0; % initial susceptible       (number of individuals)

% initial conditions vector
param.IC = [S0 E0 I0 A0 H0 R0 D0];

% -----------------------------------------------------------
%% Integration of the initial value problem
% time interval of analysis
   t0 = 1;                  % initial time (days)
   t1 = 365;                % final time   (days)
   dt = 0.1;                % time steps   (days)
tspan = t0:dt:t1;           % interval of analysis

%% Solving the equations
QoI = model_seiahrd(param,tspan);


%% Recovering the results
% time series solved
S = QoI(:,1);  % susceptible             (number of individuals)
E = QoI(:,2);  % exposed                 (number of individuals)
I = QoI(:,3);  % symptomatic infectious  (number of individuals)
A = QoI(:,4);  % asymptomatic infectious (number of individuals)
H = QoI(:,5);  % hospitalized            (number of individuals)
R = QoI(:,6);  % recovered               (number of individuals)
D = QoI(:,7);  % deceased                (number of individuals)
time = QoI(:,8);  % time                (days)
% -----------------------------------------------------------

%% Computing the basic reproduction number R_nought
R_nought = param.beta/(param.gamma+param.delta);

%% Computing the control reproduction number R_control
DI = param.gamma + param.rho + param.delta;       % mean duration in compartment I
DA = param.gamma + param.delta;             % mean duration in compartment A
DH = param.gamma + param.kappaH*param.delta;      % mean duration in compartment H
R_control = param.fE*param.beta/DI + (1-param.fE)*param.beta/DA + param.rho*param.fE*param.beta/DI/DH;

% -----------------------------------------------------------
%% Plotting all compartments of SEIAHRD model
% custom colors
yellow = [255 204  0]/256;
orange = [256 128  0]/256;
brown  = [101  33 33]/256;

figure(1)
hold on
fig1(1) = plot(time,S);
fig1(2) = plot(time,E);
fig1(3) = plot(time,I);
fig1(4) = plot(time,A);
fig1(5) = plot(time,H);
fig1(6) = plot(time,R);
fig1(7) = plot(time,D);
hold off

% plot labels
filename_fig1 = (['SEIAHRD dynamic model - Rc = ',num2str(R_control,'%2.2f'),' and Ro = ',num2str(R_nought,'%2.2f')]);
title(filename_fig1);
xlabel('time (days)'          );
ylabel('number of individuals');

% set plot settings
set(gca,'FontSize',18);
set(fig1,{'Color'},{'b';yellow;'r';orange;brown;'g';'k'});
set(fig1,{'LineWidth'},{2;2;2;2;2;2;2});

% legend
leg = {'Suceptibles'; 'Exposed'; 'Symp. Infectious';...
    'Asymp. Infectious'; 'Hospitalized';...
    'Recovered';'Deceased'};
legend(fig1,leg,'FontSize',12,'location','best');

% axis limits
xlim([t0 t1]);
ylim([0 param.N0]);

% saving
set(gcf,'renderermode','manual', 'render','zbuffer');
saveas(gcf,'seiahrd_results.png')

% -----------------------------------------------------------