% -----------------------------------------------------------------
%  model_seiahrd.m
% -----------------------------------------------------------------
% programmers: Rachel Lucena
%              Eber Dantas
%              Americo Cunha
%
% last update: August 09, 2021
% -----------------------------------------------------------------
% Function to compute the system of ODEs for the SEIAHRD epidemic model.
% -----------------------------------------------------------------
%  Input:
%   param: model parameters and initial conditions
%   param.N0     = initial population size            (number of individuals)
%   param.beta   = transmission rate                  (days^-1)
%   param.alpha  = latent rate                        (days^-1)
%   param.fE     = symptomatic fraction               (dimensionless)
%   param.gamma  = recovery rate                      (days^-1)
%   param.rho    = hospitalization rate               (days^-1)
%   param.delta  = death rate                         (days^-1)
%   param.kappaH = hospitalization mortality-factor   (dimensionless)
%   param.IC     = initial condition vector           
%   tspan        = integration parameter 
%
%  Output:
%   QoI - quantity of interest (state rate of change and time interval)
% -----------------------------------------------------------------

% -----------------------------------------------------------------
function QoI = model_seiahrd(param,tspan)
% Initial conditions
IC = param.IC;

% ODE solver Runge-Kutta45
[time, y] = ode45(@(t,y)rhs_seiahrd(y,param),tspan,IC);

% output of function
QoI = [y time];
end

%% function to define the ODE system
function dydt = rhs_seiahrd(y,param)

%% Model parameters: param = [N0 alpha fE gamma rho delta kappaH zeta]
N0       = param.N0;     % initial population size   (number of individuals)
beta     = param.beta;   % transmission rate (days^-1)
alpha    = param.alpha;  % latent rate (days^-1)
fE       = param.fE;     % symptomatic fraction (dimensionless)
gamma    = param.gamma;  % recovery rate (days^-1)
rho      = param.rho;    % hospitalization rate (days^-1)
delta    = param.delta;  % death rate (days^-1)
kappaH   = param.kappaH; % hospitalization mortality-factor (dimensionless)

[S E I A H R D] = deal(y(1),y(2),y(3),y(4),y(5),y(6),y(7));

% state equations
N = N0 - D;
dSdt = - beta*S.*(I+A+H)./N;
dEdt = beta*S.*(I+A+H)./N - alpha*E;
dIdt = fE*alpha*E - (gamma+rho+delta)*I;
dAdt = (1-fE)*alpha*E - (gamma+delta)*A;
dHdt = rho*I - (gamma+kappaH*delta)*H;
dRdt = gamma*(I+A+H);
dDdt = delta*(I+A+kappaH*H);

% system of ODEs
dydt = [dSdt; dEdt; dIdt; dAdt; dHdt; dRdt; dDdt];
end
% -----------------------------------------------------------------
