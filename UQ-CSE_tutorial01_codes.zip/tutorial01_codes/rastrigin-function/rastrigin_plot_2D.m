% ----------------------------------------------------------------- 
%  programmer: Marcos Vinicius Issa
%              marcos.issa@uerj.br
%
%  last update: August 08, 2021
% -----------------------------------------------------------------


function rastrigin_plot_2D(x1min,x1max,x2min,x2max)

% Contour Plot

hold on
    
    [x1, x2] = meshgrid (x1min:0.01:x1max,x2min:0.01:x2max);      
    
    %Rastrigin Function
    J = 20 + (x1.^2 - 10.*cos(2.*pi.*x1)) + (x2.^2 - 10.*cos(2.*pi.*x2));
    
    mesh(x1,x2,J);
    
    xlabel('\it{x_1}','FontSize',20); ylabel('\it{x_2}','FontSize',20);
    zlabel('$f(x)$','Interpreter','latex','FontSize',20);
    
    
    set(gca,'FontSize',20)
    
    az = 45;
    el = 15;
    view(az, el);

hold off

end
