% -----------------------------------------------------------------
%  main_damagedetection.m
% -----------------------------------------------------------------
%  programmer: Bruna Pavlack
%              Samuel da Silva
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
%  This code performs damage detection on a Degree of Freedom 
%  System (SDoF), the damage being a loss in stiffness. An outlier 
%  with an empirical approach is used.
% -----------------------------------------------------------------
%
%  Input:
%  Damage index (index) - obtained by the Mahalanobis distance, 
%  using the natural frequency and prediction error features. 
%
%  Output:
%  Figure: damage Detection.
%
% -----------------------------------------------------------------
clc
clear
close all
% -----------------------------------------------------------------
disp('===========================================================================');
disp('   Damage detection in an SDoF                                             ');
disp('   Undamped, m=1 kg, k=1000 N/m and random excitation force                ');
disp('   Simulated damage: loss of stiffness of 10%, 20%, 30%, 40% and 50%       ');
disp('===========================================================================');

%  Damage index: obtained by the Mahalanobis distance, using the 
%  natural frequency and prediction error features. 

disp('  -- Loading feature data: natural frequency and AR prediction error --  ');

load dados          % Natural frequencies
load ARfeatures     % AR prediction error


disp('  -- Learning and validation data --  ');

%  Using half of data for learning and half for validation
%  Stiffnnes reduction - damage simulation
%  kd = [0.9*k 0.8*k 0.7*k 0.6*k 0.5*k];   
%  Rep = 100;

observation = randperm(Rep);
learn = observation(1:Rep/2);
valida = observation(Rep/2+1:Rep);

%  Learning data
Xh = FeatWh(learn)';
Yh = Gammah(learn)';

%  Validation data - healthy state
Xhv = FeatWh(valida)';
Yhv = Gammah(valida)';

%  Validation data - damaged state (stifiness reduction: kd = [0.9*k 0.8*k 0.7*k 0.6*k 0.5*k]) 

G = [Gammad(:,1); Gammad(:,2); Gammad(:,3); Gammad(:,4); Gammad(:,5)];
F = [FeatW(:,1); FeatW(:,2); FeatW(:,3); FeatW(:,4); FeatW(:,5)];


disp('  -- Damage index by Mahalanobis distance --  ');

%  Learning a statistical model. Damage index obtained by the Mahalanobis distance

Disth = mahal([Xh Yh],[Xh Yh]);         % learning
Disthv = mahal([Xhv Yhv],[Xh Yh]);      % healthy validation
Distd = mahal([F G],[Xh Yh]);           % damaged validation

save index Disth Disthv Distd Rep learn valida

load index

% Damage Detection Figure
% Outlier: Empirical approach - maximum point of the observation in a healthy state 
% into the learning data is used as a threshold.

disp('  -- Damage Detection Figure --  ');

marcador = 15;
nfonte = 35;

figure
set(gcf,'Units', 'Normalized', 'OuterPosition', [0 0 1 0.6]);

semilogy(learn,Disth,'ob','MarkerSize',marcador); grid minor; hold on
semilogy(valida,Disthv ,'xk','MarkerSize',marcador); 
semilogy(Rep+1:Rep+5*Rep,Distd,'dr','MarkerSize',marcador); 
yline(max(Disth),'k--','linewidth', 3)
xlabel('Tests','FontSize',nfonte,'interpreter','latex'); 
ylabel('$\mathcal D^2$','FontSize',nfonte,'interpreter','latex'); 
set(gca,'FontSize',nfonte ,'TickLabelInterpreter','latex')
l = legend('Healthy - learning data','Healthy - validation data','Damaged - validation data','Threshold','Location','southeast');
set(l,'interpreter', 'latex')
set(l,'FontSize',16);
% -----------------------------------------------------------------

disp('             ...               ');
disp('  -- successfully finished --  ');