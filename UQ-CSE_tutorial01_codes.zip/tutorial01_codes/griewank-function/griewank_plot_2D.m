% ----------------------------------------------------------------- 
%  programmer: Marcos Vinicius Issa
%              marcos.issa@uerj.br
%
%  last update: August 08, 2021
% -----------------------------------------------------------------


function griewank_plot_2D(x1min,x1max,x2min,x2max)

% Contour Plot

hold on

   [x1, x2] = meshgrid (x1min:0.01:x1max, x2min:0.01:x2max);   

    J = (x1.^2./4000)+ (x2.^2./4000) - cos(x1./sqrt(1)).*cos(x2./sqrt(2)) + 1;
    
    mesh(x1,x2,J);
    
    xlabel('\it{x_1}','FontSize',20); ylabel('\it{x_2}','FontSize',20);
    zlabel('$f(x)$','Interpreter','latex','FontSize',20);
    
    
    set(gca,'FontSize',20)
    
    az = 35;
    el = 10;
    view(az, el);


hold off


end